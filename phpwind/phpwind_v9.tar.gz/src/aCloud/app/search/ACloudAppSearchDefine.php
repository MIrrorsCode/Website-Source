<?php

define ( 'APP_SEARCH_APPID', '200813330755562391' );
define ( 'APP_SEARCH_HOST', 's.phpwind.com' );


