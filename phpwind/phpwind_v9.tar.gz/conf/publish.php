<?php 
defined('WEKIT_VERSION') or exit(403);
/**
 * 外部可访问资源部署目录配置
 */
return array(

/**=====配置开始于此=====**/

/**
 * 可访问目录
 */

'PUBLIC_URL'         => '',
'PUBLIC_ATTACH'      => '/attachment',
'PUBLIC_HTML'        => '/html',
'PUBLIC_RES'         => '/res',
'PUBLIC_THEMES'      => '/themes',


/**=====配置结束于此=====**/
);